#!/usr/bin/env python3
"""
scrask_bot.py
Scrask Bot — Google Calendar / Tasks writer

Receives pre-parsed structured JSON from the OpenClaw agent (which handles
all vision and AI parsing using its configured model) and writes items to
Google Calendar or Google Tasks.

Usage:
  python3 scrask_bot.py --json-input '<json string>'
  python3 scrask_bot.py --json-file /path/to/parsed.json
  cat parsed.json | python3 scrask_bot.py --stdin

Input JSON schema (produced by OpenClaw agent per SKILL.md prompt):
  {
    "items": [
      {
        "type": "event" | "reminder" | "task",
        "confidence": 0.0-1.0,
        "title": "...",
        "date": "YYYY-MM-DD or null",
        "time": "HH:MM (24h) or null",
        "end_time": "HH:MM or null",
        "timezone_hint": "IANA string or null",
        "location": "...",
        "online_link": "...",
        "recurrence": "none | daily | weekly | monthly | yearly",
        "recurrence_day": "Tuesday or null",
        "description": "...",
        "priority": "high | medium | low",
        "source_type": "whatsapp | email | social_media | chat | flyer | other",
        "already_in_calendar_hint": true | false
      }
    ],
    "screenshot_summary": "...",
    "no_actionable_content": true | false,
    "parse_notes": "..."
  }

Env vars:
  GOOGLE_CREDENTIALS  — path to Google service account JSON
  USER_TIMEZONE       — fallback IANA timezone if not in config

Requirements:
  pip install -r requirements.txt
"""

import argparse
import json
import os
import sys
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

try:
    from google.oauth2 import service_account
    from googleapiclient.discovery import build
    GOOGLE_AVAILABLE = True
except ImportError:
    GOOGLE_AVAILABLE = False


# ─── Constants ─────────────────────────────────────────────────────────────────

CONFIDENCE_THRESHOLD   = 0.75
DEFAULT_EVENT_DURATION = 60   # minutes
DEFAULT_REMINDER_LEAD  = 30   # minutes

GOOGLE_SCOPES = [
    "https://www.googleapis.com/auth/calendar",
    "https://www.googleapis.com/auth/tasks",
]


# ─── Google helpers ────────────────────────────────────────────────────────────

def get_google_services(credentials_path: str):
    if not GOOGLE_AVAILABLE:
        raise RuntimeError(
            "Google client libraries not installed. "
            "Run: pip install google-auth google-auth-httplib2 google-api-python-client"
        )
    creds = service_account.Credentials.from_service_account_file(
        credentials_path, scopes=GOOGLE_SCOPES
    )
    calendar = build("calendar", "v3", credentials=creds)
    tasks    = build("tasks",    "v1", credentials=creds)
    return calendar, tasks


def build_datetime(date_str: str, time_str: str | None, tz: str) -> str:
    try:
        tzinfo = ZoneInfo(tz)
    except ZoneInfoNotFoundError:
        tzinfo = ZoneInfo("UTC")

    if time_str:
        dt = datetime.strptime(f"{date_str} {time_str}", "%Y-%m-%d %H:%M")
        return dt.replace(tzinfo=tzinfo).isoformat()
    return date_str


def create_calendar_event(service, item: dict, timezone: str, reminder_minutes: int) -> str:
    tz_hint  = item.get("timezone_hint") or timezone
    start_dt = build_datetime(item["date"], item.get("time"), tz_hint)

    if item.get("end_time"):
        end_dt = build_datetime(item["date"], item["end_time"], tz_hint)
    elif item.get("time"):
        start  = datetime.fromisoformat(start_dt)
        end_dt = (start + timedelta(minutes=DEFAULT_EVENT_DURATION)).isoformat()
    else:
        end_dt = start_dt

    body = {
        "summary":     item["title"],
        "description": (item.get("description") or "") + "\n\n[Added by Scrask]",
        "start": {"dateTime": start_dt, "timeZone": tz_hint}
                 if item.get("time") else {"date": start_dt},
        "end":   {"dateTime": end_dt,   "timeZone": tz_hint}
                 if item.get("time") else {"date": end_dt},
        "reminders": {
            "useDefault": False,
            "overrides":  [{"method": "popup", "minutes": reminder_minutes}],
        },
    }

    if item.get("location"):
        body["location"] = item["location"]

    if item.get("online_link"):
        body["description"] += f"\n\nJoin: {item['online_link']}"
        body["location"] = item["online_link"]

    if item.get("recurrence") and item["recurrence"] != "none":
        freq_map = {
            "daily": "DAILY", "weekly": "WEEKLY",
            "monthly": "MONTHLY", "yearly": "YEARLY",
        }
        rrule = f"RRULE:FREQ={freq_map[item['recurrence']]}"
        if item.get("recurrence_day") and item["recurrence"] == "weekly":
            day_map = {
                "monday": "MO", "tuesday": "TU", "wednesday": "WE",
                "thursday": "TH", "friday": "FR", "saturday": "SA", "sunday": "SU",
            }
            day_code = day_map.get(item["recurrence_day"].lower())
            if day_code:
                rrule += f";BYDAY={day_code}"
        body["recurrence"] = [rrule]

    result = service.events().insert(calendarId="primary", body=body).execute()
    return result.get("htmlLink", "")


def create_task(service, item: dict) -> str:
    body = {
        "title": item["title"],
        "notes": (item.get("description") or "") + "\n[Added by Scrask]",
    }
    if item.get("date"):
        body["due"] = f"{item['date']}T00:00:00.000Z"

    result = service.tasks().insert(tasklist="@default", body=body).execute()
    return result.get("id", "")


# ─── Decision engine ───────────────────────────────────────────────────────────

def process_item(item: dict) -> dict:
    confidence  = item.get("confidence", 0.0)
    item_type   = item.get("type", "task")
    destination = "google_calendar" if item_type == "event" else "google_tasks"

    return {
        "item":               item,
        "confidence":         confidence,
        "needs_confirmation": confidence < CONFIDENCE_THRESHOLD,
        "destination":        destination,
        "action_taken":       None,
        "link":               None,
        "error":              None,
    }


def execute_item(result: dict, credentials_path: str, timezone: str) -> dict:
    item = result["item"]
    try:
        cal_service, tasks_service = get_google_services(credentials_path)
    except Exception as e:
        result["error"] = f"Google auth failed: {e}"
        return result

    try:
        if result["destination"] == "google_calendar":
            link = create_calendar_event(cal_service, item, timezone, DEFAULT_REMINDER_LEAD)
            result["action_taken"] = "created_calendar_event"
            result["link"]         = link
        else:
            task_id = create_task(tasks_service, item)
            result["action_taken"] = "created_google_task"
    except Exception as e:
        result["error"] = str(e)

    return result


# ─── Telegram reply formatter ──────────────────────────────────────────────────

def format_telegram_reply(results: list[dict], parse_data: dict) -> str:
    lines = []
    silent_items  = [r for r in results if not r["needs_confirmation"]]
    confirm_items = [r for r in results if r["needs_confirmation"]]

    for r in silent_items:
        item = r["item"]
        if r.get("error"):
            lines.append(f"⚠️ Failed to save **{item['title']}**: {r['error']}")
            continue
        if r["destination"] == "google_calendar":
            when = f"{item.get('date', '')} at {item['time']}" if item.get("time") else item.get("date", "")
            lines.append(f"📅 Added to Calendar: **{item['title']}** — {when}")
        else:
            due  = f" (due {item['date']})" if item.get("date") else ""
            icon = "🔔" if item.get("date") else "✅"
            lines.append(f"{icon} Added to Tasks: **{item['title']}**{due}")

    for r in confirm_items:
        item = r["item"]
        lines.append(f"\n🤔 Not sure about this one (confidence: {int(r['confidence']*100)}%)")
        if r["destination"] == "google_calendar":
            lines.append(f"📅 **Event detected**")
            lines.append(f"  Title: {item['title']}")
            lines.append(f"  Date:  {item.get('date') or '?'}")
            lines.append(f"  Time:  {item.get('time') or '?'}")
            if item.get("location"):
                lines.append(f"  Where: {item['location']}")
            if item.get("online_link"):
                lines.append(f"  Link:  {item['online_link']}")
        else:
            icon  = "🔔" if item.get("date") else "✅"
            label = "Reminder" if item.get("date") else "Task"
            lines.append(f"{icon} **{label} detected**")
            lines.append(f"  Title: {item['title']}")
            if item.get("date"):
                lines.append(f"  Due:   {item['date']}")
        if item.get("description"):
            lines.append(f"  Note:  {item['description']}")
        lines.append("\nSave it? Reply **yes**, **edit**, or **skip**.")

    if parse_data.get("parse_notes"):
        lines.append(f"\n_ℹ️ {parse_data['parse_notes']}_")

    return "\n".join(lines).strip()


# ─── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Scrask Bot — write pre-parsed screenshot data to Google Calendar / Tasks."
    )

    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--json-input",  help="Parsed JSON string from OpenClaw agent")
    group.add_argument("--json-file",   help="Path to JSON file from OpenClaw agent")
    group.add_argument("--stdin",       action="store_true", help="Read JSON from stdin")

    parser.add_argument(
        "--timezone",
        default=os.environ.get("USER_TIMEZONE", "UTC"),
        help="Fallback IANA timezone (e.g. Asia/Kolkata)",
    )
    parser.add_argument(
        "--google-credentials",
        default=os.environ.get("GOOGLE_CREDENTIALS", ""),
        help="Path to Google service account JSON",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Classify only — do not call Google APIs",
    )

    args = parser.parse_args()

    # Load JSON
    try:
        if args.json_input:
            parse_data = json.loads(args.json_input)
        elif args.json_file:
            parse_data = json.loads(open(args.json_file).read())
        else:
            parse_data = json.loads(sys.stdin.read())
    except json.JSONDecodeError as e:
        exit_error(f"Invalid JSON from OpenClaw agent: {e}")

    # No actionable content
    if parse_data.get("no_actionable_content") or not parse_data.get("items"):
        print(json.dumps({
            "success":              False,
            "no_actionable_content": True,
            "screenshot_summary":   parse_data.get("screenshot_summary", ""),
            "telegram_reply": (
                "🤷 I couldn't find any event, reminder, or task info in that screenshot.\n"
                "Could you describe what you'd like to add?"
            ),
        }, indent=2, ensure_ascii=False))
        return

    # Classify
    results = [process_item(item) for item in parse_data["items"]]

    # Execute high-confidence items
    if not args.dry_run:
        credentials = args.google_credentials
        if not credentials:
            exit_error("GOOGLE_CREDENTIALS not set. Cannot write to Google APIs.")
        for r in results:
            if not r["needs_confirmation"]:
                execute_item(r, credentials, args.timezone)

    # Output
    telegram_reply = format_telegram_reply(results, parse_data)

    print(json.dumps({
        "success":                    True,
        "screenshot_summary":         parse_data.get("screenshot_summary", ""),
        "items_found":                len(results),
        "items_saved":                sum(1 for r in results if r.get("action_taken")),
        "items_pending_confirmation": sum(1 for r in results if r["needs_confirmation"]),
        "results": [
            {
                "title":              r["item"]["title"],
                "type":               r["item"]["type"],
                "confidence":         r["confidence"],
                "destination":        r["destination"],
                "needs_confirmation": r["needs_confirmation"],
                "action_taken":       r.get("action_taken"),
                "link":               r.get("link"),
                "error":              r.get("error"),
            }
            for r in results
        ],
        "telegram_reply": telegram_reply,
        "parse_notes":    parse_data.get("parse_notes"),
    }, indent=2, ensure_ascii=False))


def exit_error(message: str) -> None:
    sys.stderr.write(
        json.dumps({
            "error":          True,
            "message":        message,
            "success":        False,
            "telegram_reply": f"⚠️ Something went wrong: {message}",
        }) + "\n"
    )
    sys.exit(1)


if __name__ == "__main__":
    main()
