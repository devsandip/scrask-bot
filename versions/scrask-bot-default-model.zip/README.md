# 🦞 Scrask Bot

**OpenClaw Skill** — Send a screenshot to Telegram. Scrask saves it to Google Calendar or Tasks automatically.

**Scrask** = Screenshot + Task

---

## What It Does

1. You take a screenshot on your phone (WhatsApp forward, email, social post, chat)
2. You send it to your OpenClaw bot on Telegram
3. OpenClaw's configured model parses it
4. Scrask saves it to the right place — no input needed from you

| Detected type | Destination |
|---|---|
| Event (date + time / venue / invite link) | Google Calendar |
| Reminder (deadline, due date) | Google Tasks (with due date) |
| Task (no date, action item) | Google Tasks |

High confidence (≥ 0.75) → saves silently, confirms in chat  
Low confidence → shows preview, asks before saving

---

## Architecture

Scrask is intentionally split into two layers:

**Layer 1 — Vision (OpenClaw agent)**  
The OpenClaw agent parses the screenshot using whatever model is configured in OpenClaw. No separate API key or AI SDK needed. The agent produces structured JSON.

**Layer 2 — Google API writer (Python script)**  
`scrask_bot.py` receives that JSON and handles all Google Calendar / Tasks writes. It has no AI logic — just Google API calls.

This means Scrask automatically uses whichever model you've configured in OpenClaw (GPT-4o, Claude, Gemini, Llama — anything). No changes to the skill needed when you switch models.

---

## Installation

```bash
# 1. Copy to OpenClaw skills directory
cp -r scrask-bot ~/.openclaw/skills/

# 2. Install dependencies (Google API only — no AI SDKs)
pip install -r ~/.openclaw/skills/scrask-bot/scripts/requirements.txt

# 3. Set up Google credentials
# → Google Cloud Console → create service account
# → Enable Calendar API + Tasks API
# → Download JSON key → save as ~/.openclaw/google-creds.json
# → Share your Google Calendar with the service account email

# 4. Add to openclaw.json (see below)

# 5. Restart OpenClaw
openclaw restart
```

### openclaw.json config

```json
{
  "skills": {
    "entries": {
      "scrask-bot": {
        "enabled": true,
        "env": {
          "GOOGLE_CREDENTIALS": "/home/user/.openclaw/google-creds.json"
        },
        "config": {
          "timezone": "Asia/Kolkata",
          "confidence_threshold": 0.75,
          "reminder_minutes_before": 30
        }
      }
    }
  }
}
```

No `ANTHROPIC_API_KEY` or `GEMINI_API_KEY` needed — Scrask uses OpenClaw's model.

---

## Testing

```bash
# Supply pre-parsed JSON directly (no OpenClaw needed for testing the writer)
python3 scripts/scrask_bot.py \
  --json-input '{
    "items": [{
      "type": "event",
      "confidence": 0.92,
      "title": "Team standup",
      "date": "2026-03-01",
      "time": "09:00",
      "end_time": null,
      "timezone_hint": "Asia/Kolkata",
      "location": null,
      "online_link": null,
      "recurrence": "none",
      "recurrence_day": null,
      "description": "Daily team standup",
      "priority": "medium",
      "source_type": "chat",
      "already_in_calendar_hint": false
    }],
    "screenshot_summary": "WhatsApp message about a team standup",
    "no_actionable_content": false,
    "parse_notes": null
  }' \
  --timezone "Asia/Kolkata" \
  --dry-run
```

---

## File Structure

```
scrask-bot/
├── SKILL.md                  # OpenClaw skill instructions (agent does vision parsing)
├── README.md                 # This file
└── scripts/
    ├── scrask_bot.py         # Google API writer — no AI logic
    └── requirements.txt      # Google client libraries only
```

---

## Built by

Sandip — [github.com/your-handle](https://github.com/your-handle)

---

## License

MIT
