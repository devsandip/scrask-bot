---
name: scrask-bot
version: 4.0.0
description: >
  When the user sends a screenshot via Telegram, parse it using OpenClaw's
  configured vision model, then save results to Google Calendar (events) or
  Google Tasks (reminders and tasks). Saves silently if confidence is high;
  asks for confirmation if uncertain.
author: your-name
metadata:
  openclaw:
    emoji: "🦞"
    requires:
      env:
        - GOOGLE_CREDENTIALS
      bins:
        - python3
    config:
      timezone:
        type: string
        description: "User's IANA timezone. Used when none is detected in the screenshot."
        default: "UTC"
      confidence_threshold:
        type: number
        description: "0.0–1.0. Items below this score ask for confirmation. Items above save silently."
        default: 0.75
      reminder_minutes_before:
        type: integer
        description: "Popup reminder lead time in minutes for Google Calendar events."
        default: 30
---

# Scrask Bot

## Overview

This skill activates when the user sends a screenshot via **Telegram**.
**You** (the OpenClaw agent) handle all vision parsing using your configured model.
The Python script handles only the Google API writes.

**Output destinations (you decide by content type):**

| Detected type | Destination |
|---|---|
| Event (has date+time, venue, or invite link) | Google Calendar |
| Reminder (deadline, due date, personal action) | Google Tasks (with due date) |
| Task (no date, pure action item) | Google Tasks (no due date) |

---

## Trigger Conditions

Activate when:
1. The user sends a message in Telegram that contains an **image attachment**
2. The image appears to be a **screenshot** — not a photo of a person, place, or physical object
3. No other skill has already claimed the image

Do not activate for:
- Photos of people, places, food, scenery
- Screenshots of code, errors, or UI bugs (leave for other skills)
- Images the user explicitly asks to edit, describe, or analyze for another purpose

---

## Step-by-Step Instructions

### Step 1: Acknowledge Immediately

Reply in Telegram right away so the user knows the skill is working:

> "📸 Got it — analyzing your screenshot..."

Do not make the user wait silently.

---

### Step 2: Parse the Screenshot Yourself

Analyze the screenshot image using your vision capability. Extract all actionable
information and produce a JSON object matching this schema exactly:

```json
{
  "items": [
    {
      "type": "event | reminder | task",
      "confidence": 0.0,
      "title": "concise title (max 60 chars)",
      "date": "YYYY-MM-DD or null",
      "time": "HH:MM (24h) or null",
      "end_time": "HH:MM (24h) or null",
      "timezone_hint": "detected IANA timezone string or null",
      "location": "physical address or venue name or null",
      "online_link": "Zoom/Meet/Teams URL or null",
      "recurrence": "none | daily | weekly | monthly | yearly",
      "recurrence_day": "e.g. Tuesday or null",
      "description": "1-2 sentence context summary or null",
      "priority": "high | medium | low",
      "source_type": "whatsapp | email | social_media | chat | flyer | other",
      "already_in_calendar_hint": false
    }
  ],
  "screenshot_summary": "one sentence describing what this screenshot shows",
  "no_actionable_content": false,
  "parse_notes": "edge cases, ambiguities, or things to flag to the user"
}
```

**Classification rules:**
- `"event"` → specific date+time OR a venue/link; social or external gathering
- `"reminder"` → deadline/due date; personal action item with a deadline
- `"task"` → no date at all; pure to-do or action item

**Confidence scoring:**
- 0.9–1.0 All key fields present, no ambiguity
- 0.75–0.9 Most fields present, minor inference needed
- 0.5–0.75 Date or type is uncertain
- < 0.5 Very little usable info

Current date: use today's actual date.
User timezone: `$CONFIG_TIMEZONE`

---

### Step 3: Run the Writer Script

Pass your parsed JSON to the script:

```bash
python3 ~/.openclaw/skills/scrask-bot/scripts/scrask_bot.py \
  --json-input '<your JSON output from Step 2>' \
  --timezone "$CONFIG_TIMEZONE" \
  --google-credentials "$GOOGLE_CREDENTIALS"
```

The script returns a JSON object with:
- `success` — whether the write worked
- `no_actionable_content` — true if nothing found
- `results[]` — one entry per item with `confidence`, `type`, `destination`, `needs_confirmation`, `action_taken`
- `telegram_reply` — the pre-formatted message to send back to the user

---

### Step 4: Handle the Output

**If `no_actionable_content` is true:**
Reply: "🤷 I couldn't find any event, reminder, or task info in that screenshot. Could you describe what you'd like to add?"

**If `success` is true:**
Send the `telegram_reply` value directly back to the user in Telegram. Do not rephrase or reformat it — send it as-is.

---

### Step 5: Handle Confirmation Responses

If the script returned items with `needs_confirmation: true`, wait for the user's reply.

**"yes" / "save" / "add":** Re-run the script for that item with the confirmed fields, or call `calendar_create` / `tasks_create` tools directly.

**"edit":** Ask what to change, update the field, then save.

**"skip" / "no":** Reply: "Got it, skipped ✓"

---

## Edge Cases

| Scenario | Behaviour |
|---|---|
| Screenshot in Hindi, Tamil, or another language | Extract and translate silently; save title in English |
| Recurring event ("every Monday") | Set recurrence field; mention it in the reply |
| Date has already passed | Flag: "⚠️ This date has already passed. Save anyway?" |
| Multiple items in one screenshot | Process each independently; confirm per item |
| Screenshot of someone's calendar | Set `already_in_calendar_hint: true`; reply: "Looks like this event is already in your calendar 🗓️" |
| Google API auth failure | Reply with specific error; suggest re-checking GOOGLE_CREDENTIALS |
| Zoom/Meet link found | Add to Calendar as both location and description |

---

## Configuration

```json
{
  "skills": {
    "entries": {
      "scrask-bot": {
        "enabled": true,
        "env": {
          "GOOGLE_CREDENTIALS": "/home/user/.openclaw/google-creds.json"
        },
        "config": {
          "timezone": "Asia/Kolkata",
          "confidence_threshold": 0.75,
          "reminder_minutes_before": 30
        }
      }
    }
  }
}
```

---

## Permissions Required

- `image:read` — to access the screenshot from Telegram
- `network:outbound` — to call Google APIs
- `telegram:reply` — to send confirmation messages back to the user
